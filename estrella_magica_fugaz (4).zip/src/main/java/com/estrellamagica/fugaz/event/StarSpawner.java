package com.estrellamagica.fugaz.event;

import com.estrellamagica.fugaz.EstrellaMagicaFugaz;
import com.estrellamagica.fugaz.StarColor;
import com.estrellamagica.fugaz.entity.MeteorEntity;
import com.estrellamagica.fugaz.entity.ModEntities;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.PlayerList;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = EstrellaMagicaFugaz.MOD_ID)
public class StarSpawner {

    // ======== AJUSTA LA FRECUENCIA AQUI ========
    /** Cada cuantos ticks se "tira el dado" por jugador (200 = 10 s). */
    private static final int CHECK_INTERVAL = 200;
    /** Probabilidad de meteorito en cada tirada (~5 por noche). */
    private static final double SPAWN_CHANCE = 0.12;
    /** De todos los meteoritos, cuantos se estrellan (~1 por noche). */
    private static final double IMPACT_CHANCE = 0.22;
    // ===========================================

    /** Motivo del ultimo fallo (se muestra en el comando). */
    private static String lastFail = "";

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;
        if (level.getGameTime() % CHECK_INTERVAL != 0) return;

        long t = level.getDayTime() % 24000L;
        if (t < 13000L || t > 23000L) return; // solo de noche
        if (level.isThundering()) return;

        for (ServerPlayer player : level.players()) {
            if (player.isSpectator()) continue;
            if (level.random.nextDouble() < SPAWN_CHANCE) {
                spawnMeteor(level, player, level.random.nextDouble() < IMPACT_CHANCE, false);
            }
        }
    }

    /**
     * Crea un meteorito, reintentando hasta 25 veces con otras posiciones.
     * Devuelve el punto de impacto (o el punto final si pasa de largo), o null si no se pudo.
     */
    public static Vec3 spawnMeteor(ServerLevel level, ServerPlayer player, boolean impact, boolean inFront) {
        PlayerList pl = level.getServer().getPlayerList();
        // distancia maxima fiable segun la configuracion del servidor/mundo
        double limit = Math.min(pl.getSimulationDistance(), pl.getViewDistance()) * 16.0 - 24.0;
        limit = Math.max(limit, 64.0);
        lastFail = "sin intentos";
        for (int i = 0; i < 25; i++) {
            Vec3 res = trySpawn(level, player, impact, limit, inFront);
            if (res != null) return res;
        }
        return null;
    }

    private static Vec3 trySpawn(ServerLevel level, ServerPlayer player, boolean impact, double limit, boolean inFront) {
        RandomSource r = level.random;

        // inFront = true (comandos): el meteorito cruza justo delante de ti, de izquierda a derecha
        Vec3 look = player.getLookAngle();
        double baseAng = Math.atan2(look.z, look.x);
        double ang = inFront ? baseAng - 0.9 : r.nextDouble() * Math.PI * 2;
        double startDist = inFront
                ? Math.max(55.0, Math.min(85.0, limit * 0.9))
                : Math.max(55.0, Math.min(90 + r.nextDouble() * 45, limit * 0.95));
        double startY = inFront
                ? Math.min(player.getY() + 65 + r.nextDouble() * 15, level.getMaxBuildHeight() - 10)
                : Math.min(player.getY() + 85 + r.nextDouble() * 35, level.getMaxBuildHeight() - 10);
        Vec3 start = new Vec3(player.getX() + Math.cos(ang) * startDist, startY,
                player.getZ() + Math.sin(ang) * startDist);

        if (!level.isPositionEntityTicking(BlockPos.containing(start))) {
            lastFail = "el punto de salida queda fuera de la distancia de simulacion (subela en opciones)";
            return null;
        }

        float size;
        Vec3 target;
        double speed;
        int life;

        if (impact) {
            size = 7f + r.nextFloat() * 5f; // 7 - 12 bloques de radio
            // cruza el cielo y cae al otro lado del jugador
            double a2 = inFront ? baseAng + 0.5 + r.nextDouble() * 0.3
                    : ang + Math.PI + (r.nextDouble() - 0.5) * 1.2;
            double dMax = Math.max(60.0, Math.min(100.0, limit * 0.75));
            double d = inFront ? Math.max(55.0, Math.min(70.0, dMax)) : 55 + r.nextDouble() * (dMax - 55);
            int tx = (int) Math.floor(player.getX() + Math.cos(a2) * d);
            int tz = (int) Math.floor(player.getZ() + Math.sin(a2) * d);
            if (!level.hasChunksAt(tx - 18, level.getMinBuildHeight(), tz - 18,
                    tx + 18, level.getMaxBuildHeight(), tz + 18)) {
                lastFail = "la zona de impacto no esta cargada";
                return null;
            }
            int ty = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, tx, tz);
            if (ty <= level.getMinBuildHeight()) {
                lastFail = "no hay terreno en la zona de impacto";
                return null;
            }
            if (!level.getFluidState(new BlockPos(tx, ty - 1, tz)).isEmpty()) {
                lastFail = "la zona de impacto era agua o lava";
                return null;
            }
            target = new Vec3(tx + 0.5, ty, tz + 0.5);
            speed = 0.8 + r.nextDouble() * 0.3; // lento = mas tiempo en el cielo
            life = 1400;
        } else {
            size = 6f + r.nextFloat() * 4f; // 6 - 10 bloques de radio
            double a2 = inFront ? baseAng + 0.9 : ang + Math.PI + (r.nextDouble() - 0.5) * 1.0;
            target = new Vec3(player.getX() + Math.cos(a2) * startDist * (inFront ? 1.0 : 0.9),
                    startY - 25 - r.nextDouble() * 20,
                    player.getZ() + Math.sin(a2) * startDist * 0.9);
            speed = 0.5 + r.nextDouble() * 0.3; // ~12-15 s cruzando el cielo
            life = (int) (start.distanceTo(target) / speed * 0.92);
        }

        Vec3 velocity = target.subtract(start).normalize().scale(speed);
        StarColor color = StarColor.byIndex(r.nextInt(StarColor.values().length));

        MeteorEntity meteor = new MeteorEntity(ModEntities.METEOR.get(), level);
        meteor.setPos(start.x, start.y, start.z);
        meteor.configure(color, size, impact, velocity, life);
        if (!level.addFreshEntity(meteor)) {
            lastFail = "el servidor no permitio crear la entidad";
            return null;
        }
        return target;
    }

    // /meteoro caer   -> meteorito que se estrella
    // /meteoro pasar  -> meteorito que cruza el cielo
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("meteoro")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("caer").executes(ctx -> run(ctx.getSource(), true)))
                .then(Commands.literal("pasar").executes(ctx -> run(ctx.getSource(), false))));
    }

    private static int run(CommandSourceStack src, boolean impact) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        Vec3 res = spawnMeteor(p.serverLevel(), p, impact, true);
        if (res == null) {
            src.sendFailure(Component.literal("No se pudo crear el meteorito: " + lastFail));
            return 0;
        }
        final String msg;
        if (impact) {
            double dx = res.x - p.getX();
            double dz = res.z - p.getZ();
            msg = String.format("Meteorito en camino. Impacto previsto en X=%d Y=%d Z=%d (a %d bloques de ti). Mira al cielo.",
                    (int) res.x, (int) res.y, (int) res.z, (int) Math.sqrt(dx * dx + dz * dz))
                    + " Mira hacia delante: cruzara de izquierda a derecha.";
        } else {
            msg = "Meteorito en camino. Mira HACIA DELANTE y arriba: cruzara de izquierda a derecha en unos 8 segundos.";
        }
        src.sendSuccess(() -> Component.literal(msg), false);
        return 1;
    }
}
