package com.estrellamagica.fugaz.entity;

import com.estrellamagica.fugaz.StarColor;
import com.estrellamagica.fugaz.event.StarFx;
import com.estrellamagica.fugaz.particle.ModParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

/**
 * Meteorito gigante. Se dibuja con MeteorRenderer (esferas brillantes + cola + destellos)
 * y con particulas. Si "impactMeteor" es true cae y choca contra el terreno; si no,
 * cruza el cielo y se desintegra en una gran explosion de luz.
 */
public class MeteorEntity extends Entity {
    private static final EntityDataAccessor<Integer> COLOR =
            SynchedEntityData.defineId(MeteorEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> SIZE =
            SynchedEntityData.defineId(MeteorEntity.class, EntityDataSerializers.FLOAT);

    private boolean impactMeteor = false;
    private int maxLife = 200;

    public MeteorEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.noCulling = true;
        this.setNoGravity(true);
    }

    public void configure(StarColor color, float size, boolean impact, Vec3 velocity, int life) {
        this.entityData.set(COLOR, color.ordinal());
        this.entityData.set(SIZE, size);
        this.impactMeteor = impact;
        this.maxLife = life;
        this.setDeltaMovement(velocity);
    }

    public StarColor getStarColor() { return StarColor.byIndex(this.entityData.get(COLOR)); }
    public float getMeteorSize() { return this.entityData.get(SIZE); }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(COLOR, 0);
        this.entityData.define(SIZE, 4.0f);
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return true; // se ve desde lejisimos
    }

    @Override
    public void tick() {
        super.tick();
        Vec3 motion = this.getDeltaMovement();
        Vec3 from = this.position();
        Vec3 to = from.add(motion);
        float size = getMeteorSize();

        if (!this.level().isClientSide) {
            if (this.tickCount % 10 == 1) {
                // rugido grave del meteorito atravesando la atmosfera
                this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                        SoundEvents.FIRECHARGE_USE, SoundSource.AMBIENT, 4.0f + size * 2f, 0.45f);
            }
            if (this.impactMeteor) {
                Vec3 dir = motion.normalize();
                // sondea un poco por delante: la bola es grande y "toca" antes de que llegue el centro
                Vec3 probe = to.add(dir.scale(size * 0.6));
                BlockHitResult hit = this.level().clip(new ClipContext(from, probe,
                        ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
                if (hit.getType() != HitResult.Type.MISS) {
                    impact(hit.getLocation());
                    return;
                }
                if (to.y < this.level().getMinBuildHeight()) {
                    this.discard();
                    return;
                }
            }
            if (this.tickCount > this.maxLife) {
                airBurst(from, size);
                return;
            }
        } else {
            clientFx(to, motion, size);
        }
        this.setPos(to.x, to.y, to.z);
    }

    // ------------------------------------------------------------------ cliente
    private Vec3 randomDir() {
        double x, y, z;
        do {
            x = this.random.nextDouble() * 2 - 1;
            y = this.random.nextDouble() * 2 - 1;
            z = this.random.nextDouble() * 2 - 1;
        } while (x * x + y * y + z * z > 1 || x * x + y * y + z * z < 1.0E-4);
        return new Vec3(x, y, z);
    }

    private void clientFx(Vec3 to, Vec3 motion, float size) {
        StarColor c = getStarColor();
        Vec3 dir = motion.normalize();
        float cr = c.r(), cg = c.g(), cb = c.b();

        // chispas alrededor de la bola
        for (int i = 0; i < 12; i++) {
            Vec3 off = randomDir().scale(size * (0.6 + this.random.nextDouble() * 0.6));
            this.level().addParticle(ModParticles.STAR_GLOW.get(), true,
                    to.x + off.x, to.y + off.y, to.z + off.z, cr, cg, cb);
        }
        // estela de chispas que se va ensanchando
        double len = size * 9;
        for (int i = 0; i < 16; i++) {
            double back = this.random.nextDouble() * len;
            double spread = size * (0.25 + 0.6 * back / len);
            Vec3 p = to.subtract(dir.scale(back)).add(randomDir().scale(spread * this.random.nextDouble()));
            this.level().addParticle(ModParticles.STAR_GLOW.get(), true, p.x, p.y, p.z, cr, cg, cb);
        }
        // llamas y humo que se quedan en el cielo
        for (int i = 0; i < 4; i++) {
            double back = this.random.nextDouble() * len * 0.7;
            Vec3 p = to.subtract(dir.scale(back)).add(randomDir().scale(size * 0.4));
            this.level().addParticle(ParticleTypes.FLAME, true, p.x, p.y, p.z, 0, 0, 0);
        }
        for (int i = 0; i < 3; i++) {
            double back = this.random.nextDouble() * len;
            Vec3 p = to.subtract(dir.scale(back)).add(randomDir().scale(size * 0.5));
            this.level().addParticle(ParticleTypes.LARGE_SMOKE, true, p.x, p.y, p.z, 0, 0, 0);
        }
    }

    // ------------------------------------------------------------------ servidor
    /** Los meteoritos que pasan de largo estallan en luz en pleno cielo. */
    private void airBurst(Vec3 pos, float size) {
        if (this.level() instanceof ServerLevel sl) {
            StarColor c = getStarColor();
            StarFx.burst(sl, pos, c, 220, size * 3.0);
            StarFx.particles(sl, pos, ParticleTypes.FLASH, 2, 0.5, 0.5, 0.5, 0);
            StarFx.ring(sl, pos, ParticleTypes.END_ROD, 60, 0.9, 0.0);
            sl.playSound(null, pos.x, pos.y, pos.z, SoundEvents.FIREWORK_ROCKET_LARGE_BLAST_FAR,
                    SoundSource.AMBIENT, 16f, 0.5f);
            sl.playSound(null, pos.x, pos.y, pos.z, SoundEvents.LIGHTNING_BOLT_THUNDER,
                    SoundSource.AMBIENT, 12f, 0.7f);
        }
        this.discard();
    }

    private void impact(Vec3 hit) {
        if (!(this.level() instanceof ServerLevel sl)) return;
        StarColor c = getStarColor();
        float size = getMeteorSize();
        RandomSource r = sl.random;
        this.setPos(hit.x, hit.y, hit.z);

        // Onda expansiva: dano y empuje a entidades cercanas (sin romper bloques: eso lo hace el crater)
        sl.explode(this, hit.x, hit.y, hit.z, size * 1.5f, Level.ExplosionInteraction.NONE);

        // Crater (solo si mobGriefing esta activo)
        int radius = Math.round(size * 1.2f) + 1;
        BlockPos hitPos = BlockPos.containing(hit);
        if (sl.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            carveCrater(sl, hitPos, radius, c);
            lightFires(sl, hitPos, radius);
        }

        // Espectaculo
        Vec3 up = hit.add(0, 1.2, 0);
        StarFx.particles(sl, up, ParticleTypes.FLASH, 3, 1, 1, 1, 0);
        StarFx.particles(sl, up, ParticleTypes.EXPLOSION_EMITTER, 4, size, 1.0, size, 0);
        StarFx.ring(sl, up, ParticleTypes.CLOUD, 72, 1.2, 0.05);
        StarFx.ring(sl, up, ParticleTypes.CLOUD, 48, 0.6, 0.1);
        StarFx.ring(sl, up, ParticleTypes.FLAME, 48, 0.7, 0.25);
        StarFx.ring(sl, up, ParticleTypes.LARGE_SMOKE, 32, 0.35, 2.5);
        StarFx.particles(sl, up, ParticleTypes.LAVA, 50, size, 1.0, size, 1.0);
        StarFx.burst(sl, up.add(0, 2, 0), c, 260, size * 3.0);
        sl.playSound(null, hit.x, hit.y, hit.z, SoundEvents.GENERIC_EXPLODE, SoundSource.AMBIENT, 40f, 0.45f);
        sl.playSound(null, hit.x, hit.y, hit.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.AMBIENT, 40f, 0.5f);

        // Fragmentos esparcidos
        int n = 5 + (int) size + r.nextInt(4);
        for (int i = 0; i < n; i++) {
            int amount = 1 + r.nextInt(2);
            drop(sl, hit, new ItemStack(c.fragment(), amount), false);
        }
        // Objeto unico especial
        if (r.nextFloat() < c.relicChance) {
            drop(sl, hit, new ItemStack(c.relic()), true);
        }
        this.discard();
    }

    private void carveCrater(ServerLevel sl, BlockPos hitPos, int radius, StarColor c) {
        RandomSource r = sl.random;
        BlockPos center = hitPos.below(Math.max(1, radius / 3));
        int range = radius + 3;
        int debris = 0;

        for (int dx = -range; dx <= range; dx++) {
            for (int dy = -range; dy <= range; dy++) {
                for (int dz = -range; dz <= range; dz++) {
                    double dist = Math.sqrt(dx * dx + dy * dy * 1.3 + dz * dz);
                    if (dist > radius + 2.0) continue;
                    BlockPos p = center.offset(dx, dy, dz);
                    if (!sl.hasChunkAt(p)) continue;
                    BlockState st = sl.getBlockState(p);
                    if (st.isAir()) continue;
                    if (st.getDestroySpeed(sl, p) < 0 || st.is(BlockTags.WITHER_IMMUNE)) continue;
                    if (st.hasBlockEntity()) continue; // no destruir cofres, hornos...

                    double edge = radius + (r.nextDouble() - 0.5) * 1.2;
                    if (dist <= edge) {
                        if (debris < 14 && r.nextInt(70) == 0 && st.getFluidState().isEmpty()) {
                            // escombro que sale volando
                            FallingBlockEntity fb = FallingBlockEntity.fall(sl, p, st);
                            Vec3 out = new Vec3(dx + (r.nextDouble() - 0.5), 0, dz + (r.nextDouble() - 0.5));
                            out = out.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : out.normalize();
                            fb.setDeltaMovement(out.x * (0.4 + r.nextDouble() * 0.7),
                                    0.7 + r.nextDouble() * 0.8,
                                    out.z * (0.4 + r.nextDouble() * 0.7));
                            debris++;
                        } else {
                            sl.setBlock(p, Blocks.AIR.defaultBlockState(), 3);
                        }
                    } else if (dy <= 0 && st.isSolidRender(sl, p)) {
                        // borde calcinado del crater
                        float f = r.nextFloat();
                        if (f < 0.40f) sl.setBlock(p, Blocks.BLACKSTONE.defaultBlockState(), 3);
                        else if (f < 0.55f) sl.setBlock(p, Blocks.MAGMA_BLOCK.defaultBlockState(), 3);
                        else if (f < 0.70f) sl.setBlock(p, c.accentBlock.defaultBlockState(), 3);
                    }
                }
            }
        }
    }

    private void lightFires(ServerLevel sl, BlockPos hitPos, int radius) {
        RandomSource r = sl.random;
        int span = radius + 5;
        for (int i = 0; i < 35; i++) {
            int fx = hitPos.getX() + r.nextInt(span * 2 + 1) - span;
            int fz = hitPos.getZ() + r.nextInt(span * 2 + 1) - span;
            if (!sl.hasChunkAt(new BlockPos(fx, 64, fz))) continue;
            int fy = sl.getHeight(Heightmap.Types.MOTION_BLOCKING, fx, fz);
            BlockPos fp = new BlockPos(fx, fy, fz);
            BlockState fire = Blocks.FIRE.defaultBlockState();
            if (sl.getBlockState(fp).isAir() && fire.canSurvive(sl, fp)) {
                sl.setBlockAndUpdate(fp, fire);
            }
        }
    }

    private void drop(ServerLevel sl, Vec3 pos, ItemStack stack, boolean glow) {
        RandomSource r = sl.random;
        ItemEntity item = new ItemEntity(sl, pos.x, pos.y + 2.0, pos.z, stack);
        item.setDeltaMovement((r.nextDouble() - 0.5) * 1.0, 0.4 + r.nextDouble() * 0.5, (r.nextDouble() - 0.5) * 1.0);
        item.setPickUpDelay(20);
        if (glow) {
            item.setGlowingTag(true);
            item.setUnlimitedLifetime();
        }
        sl.addFreshEntity(item);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) { }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) { }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
