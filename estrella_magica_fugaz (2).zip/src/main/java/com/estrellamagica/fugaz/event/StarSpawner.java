package com.estrellamagica.fugaz.event;

import com.estrellamagica.fugaz.EstrellaMagicaFugaz;
import com.estrellamagica.fugaz.StarColor;
import com.estrellamagica.fugaz.entity.MeteorEntity;
import com.estrellamagica.fugaz.entity.ModEntities;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = EstrellaMagicaFugaz.MOD_ID)
public class StarSpawner {

    // ======== AJUSTA LA FRECUENCIA AQUI ========
    /** Cada cuantos ticks se "tira el dado" por jugador (200 = 10 s). */
    private static final int CHECK_INTERVAL = 200;
    /** Probabilidad de meteorito en cada tirada (~5 por noche). */
    private static final double SPAWN_CHANCE = 0.12;
    /** De todos los meteoritos, cuantos se estrellan (~1 por noche). */
    private static final double IMPACT_CHANCE = 0.22;
    // ===========================================

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;
        if (level.getGameTime() % CHECK_INTERVAL != 0) return;

        long t = level.getDayTime() % 24000L;
        if (t < 13000L || t > 23000L) return; // solo de noche
        if (level.isThundering()) return;

        for (ServerPlayer player : level.players()) {
            if (player.isSpectator()) continue;
            if (level.random.nextDouble() < SPAWN_CHANCE) {
                spawnMeteor(level, player, level.random.nextDouble() < IMPACT_CHANCE);
            }
        }
    }

    /** Crea un meteorito. Devuelve false si no se pudo (zona sin cargar, agua, etc.). */
    public static boolean spawnMeteor(ServerLevel level, ServerPlayer player, boolean impact) {
        RandomSource r = level.random;

        double ang = r.nextDouble() * Math.PI * 2;
        double startDist = 90 + r.nextDouble() * 45;
        double startY = Math.min(player.getY() + 85 + r.nextDouble() * 35, level.getMaxBuildHeight() - 10);
        Vec3 start = new Vec3(player.getX() + Math.cos(ang) * startDist, startY,
                player.getZ() + Math.sin(ang) * startDist);

        if (!level.isPositionEntityTicking(BlockPos.containing(start))) return false;

        float size;
        Vec3 target;
        double speed;
        int life;

        if (impact) {
            size = 4f + r.nextFloat() * 3f; // 4 - 7 bloques de radio
            // cruza el cielo y cae al otro lado, a 40-90 bloques del jugador
            double a2 = ang + Math.PI + (r.nextDouble() - 0.5) * 1.2;
            double d = 40 + r.nextDouble() * 50;
            int tx = (int) Math.floor(player.getX() + Math.cos(a2) * d);
            int tz = (int) Math.floor(player.getZ() + Math.sin(a2) * d);
            if (!level.hasChunksAt(tx - 16, level.getMinBuildHeight(), tz - 16,
                    tx + 16, level.getMaxBuildHeight(), tz + 16)) return false;
            int ty = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, tx, tz);
            if (ty <= level.getMinBuildHeight()) return false;
            if (!level.getFluidState(new BlockPos(tx, ty - 1, tz)).isEmpty()) return false; // nada de agua/lava
            target = new Vec3(tx + 0.5, ty, tz + 0.5);
            speed = 1.3 + r.nextDouble() * 0.5;
            life = 700;
        } else {
            size = 3f + r.nextFloat() * 3f; // 3 - 6 bloques de radio
            double a2 = ang + Math.PI + (r.nextDouble() - 0.5) * 1.0;
            target = new Vec3(player.getX() + Math.cos(a2) * startDist * 0.9,
                    startY - 25 - r.nextDouble() * 20,
                    player.getZ() + Math.sin(a2) * startDist * 0.9);
            speed = 0.9 + r.nextDouble() * 0.5;
            life = (int) (start.distanceTo(target) / speed * 0.92);
        }

        Vec3 velocity = target.subtract(start).normalize().scale(speed);
        StarColor color = StarColor.byIndex(r.nextInt(StarColor.values().length));

        MeteorEntity meteor = new MeteorEntity(ModEntities.METEOR.get(), level);
        meteor.setPos(start.x, start.y, start.z);
        meteor.configure(color, size, impact, velocity, life);
        level.addFreshEntity(meteor);
        return true;
    }

    // /meteoro caer   -> meteorito que se estrella
    // /meteoro pasar  -> meteorito que cruza el cielo
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("meteoro")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("caer").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    boolean ok = spawnMeteor(p.serverLevel(), p, true);
                    ctx.getSource().sendSuccess(() -> Component.literal(ok
                            ? "Meteorito en camino..." : "No se pudo (prueba de nuevo o en otra zona)."), false);
                    return ok ? 1 : 0;
                }))
                .then(Commands.literal("pasar").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    boolean ok = spawnMeteor(p.serverLevel(), p, false);
                    ctx.getSource().sendSuccess(() -> Component.literal(ok
                            ? "Meteorito en camino..." : "No se pudo (prueba de nuevo)."), false);
                    return ok ? 1 : 0;
                })));
    }
}
