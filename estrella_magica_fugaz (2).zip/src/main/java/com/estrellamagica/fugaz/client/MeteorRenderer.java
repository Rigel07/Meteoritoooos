package com.estrellamagica.fugaz.client;

import com.estrellamagica.fugaz.StarColor;
import com.estrellamagica.fugaz.entity.MeteorEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;

/**
 * Dibuja el meteorito: nucleo blanco incandescente, capas de color, halo enorme,
 * espinas giratorias y una cola larga que se desvanece (todo aditivo y a brillo maximo).
 */
public class MeteorRenderer extends EntityRenderer<MeteorEntity> {

    public MeteorRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public boolean shouldRender(MeteorEntity entity, Frustum frustum, double x, double y, double z) {
        return true; // nunca lo recortes: es gigante y debe verse desde lejos
    }

    @Override
    public void render(MeteorEntity entity, float entityYaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int packedLight) {
        Vec3 v = entity.getDeltaMovement();
        if (v.lengthSqr() < 1.0E-6) return;

        float size = entity.getMeteorSize();
        StarColor c = entity.getStarColor();
        float age = entity.tickCount + partialTick;
        float pulse = 1f + 0.05f * Mth.sin(age * 0.8f);
        float seed = entity.getId() * 1.37f;

        float cr = c.r(), cg = c.g(), cb = c.b();
        // color "caliente": el del meteorito mezclado con blanco
        float hr = Mth.lerp(0.55f, cr, 1f), hg = Mth.lerp(0.55f, cg, 1f), hb = Mth.lerp(0.55f, cb, 1f);

        VertexConsumer vc = buffer.getBuffer(RenderType.lightning());

        pose.pushPose();
        Vec3 d = v.normalize();
        // el eje +Y local apunta hacia atras (hacia donde va la cola)
        pose.mulPose(new Quaternionf().rotationTo(0f, 1f, 0f, (float) -d.x, (float) -d.y, (float) -d.z));

        // Orden: de lo mas interno a lo mas externo (por el buffer de profundidad)
        GlowShapes.sphere(vc, pose, size * 0.55f * pulse, 10, 14, 0.10f, seed, 1f, 1f, 1f, 0.95f);
        GlowShapes.sphere(vc, pose, size * 0.80f * pulse, 10, 14, 0.18f, seed + 3f, hr, hg, hb, 0.75f);
        GlowShapes.sphere(vc, pose, size * 1.20f * pulse, 10, 14, 0.08f, seed + 7f, cr, cg, cb, 0.35f);
        GlowShapes.sphere(vc, pose, size * 1.90f * pulse, 8, 12, 0.04f, seed + 9f, cr, cg, cb, 0.12f);

        // Cola (3 capas: nucleo blanco, cuerpo de color, estela difusa)
        GlowShapes.tail(vc, pose, size * 7f, size * 0.45f, 12, 7, 1f, 1f, 1f, 0.85f);
        GlowShapes.tail(vc, pose, size * 11f, size * 0.85f, 14, 8, hr, hg, hb, 0.50f);
        GlowShapes.tail(vc, pose, size * 17f, size * 1.40f, 16, 9, cr, cg, cb, 0.22f);

        // Espinas giratorias alrededor del meteorito
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(age * 3f));
        for (int i = 0; i < 6; i++) {
            pose.pushPose();
            pose.mulPose(Axis.YP.rotationDegrees(i * 60f));
            pose.mulPose(Axis.ZP.rotationDegrees(82f - (i % 2) * 18f));
            GlowShapes.spike(vc, pose, size * (2.6f + (i % 2) * 0.8f) * pulse, size * 0.16f, hr, hg, hb, 0.55f);
            pose.popPose();
        }
        pose.popPose();

        pose.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(MeteorEntity entity) {
        return new ResourceLocation("textures/misc/white.png");
    }
}
