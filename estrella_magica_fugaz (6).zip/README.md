# Estrella Mágica Fugaz 2.0 (Forge 1.20.1)

Meteoritos estelares ENORMES (azul, rosa, verde, amarillo) cruzan el cielo nocturno con una
cola enorme. Algunos pasan de largo y estallan en luz; otros se estrellan contra la tierra
abriendo un cráter, lanzando escombros, provocando fuego y dejando fragmentos de estrella y,
a veces, un objeto único.

## Compilar en GitHub
1. Sube TODO el contenido de esta carpeta (incluida `.github`) a la raíz de un repositorio.
2. Pestaña **Actions** -> "Build Estrella Magica Fugaz".
3. Al terminar: **Artifacts** -> `estrella-magica-fugaz-jar`.

## Probar rápido (operador)
- `/meteoro pasar`  -> meteorito que cruza el cielo
- `/meteoro caer`   -> meteorito que se estrella a 40-90 bloques de ti
(Funciona de día también.)

## Ajustes
- `event/StarSpawner.java`: frecuencia (SPAWN_CHANCE), proporción de impactos (IMPACT_CHANCE),
  tamaños (`size`) y velocidades.
- `StarColor.java`: probabilidad del objeto único y bloque que tiñe el cráter.
- `entity/MeteorEntity.java`: tamaño del cráter, fuego, cantidad de fragmentos.
- `client/MeteorRenderer.java`: aspecto visual (capas, cola, espinas).
- Si desactivas la gamerule `mobGriefing`, el impacto no destruye bloques.

## Recetas con los fragmentos
Crea JSON en `src/main/resources/data/estrella_magica_fugaz/recipes/`. Ejemplo:
```json
{
  "type": "minecraft:crafting_shaped",
  "pattern": [" F ", "FTF", " F "],
  "key": {
    "F": { "item": "estrella_magica_fugaz:yellow_star_fragment" },
    "T": { "item": "minecraft:torch" }
  },
  "result": { "item": "minecraft:lantern", "count": 4 }
}
```
