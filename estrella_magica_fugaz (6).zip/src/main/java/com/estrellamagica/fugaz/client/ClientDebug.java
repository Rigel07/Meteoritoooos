package com.estrellamagica.fugaz.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;

/** Mensaje de diagnostico: confirma que el cliente ha recibido el meteorito. */
public class ClientDebug {
    public static final boolean ENABLED = true; // ponlo en false cuando todo funcione

    public static void entityArrived(Entity e) {
        if (!ENABLED) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        int d = (int) mc.player.position().distanceTo(e.position());
        mc.player.displayClientMessage(Component.literal(
                "[Meteoro] Tu cliente ha recibido el meteorito (a " + d + " bloques). "
                        + "Si no lo ves, el problema es el dibujado (shaders)."), false);
    }
}
