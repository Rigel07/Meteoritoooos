package com.estrellamagica.fugaz.client;

import com.estrellamagica.fugaz.StarColor;
import com.estrellamagica.fugaz.entity.MeteorEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;

/**
 * Meteorito: nucleo de roca incandescente (bloque de magma gigante, visible incluso con shaders)
 * + capas luminosas aditivas, halo, espinas giratorias y cola larga.
 */
public class MeteorRenderer extends EntityRenderer<MeteorEntity> {
    private final BlockRenderDispatcher blockRenderer;

    public MeteorRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.blockRenderer = context.getBlockRenderDispatcher();
    }

    @Override
    public boolean shouldRender(MeteorEntity entity, Frustum frustum, double x, double y, double z) {
        return true;
    }

    @Override
    public void render(MeteorEntity entity, float entityYaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int packedLight) {
        Vec3 v = entity.getDeltaMovement();
        if (v.lengthSqr() < 1.0E-6) return;

        float size = entity.getMeteorSize();
        StarColor c = entity.getStarColor();
        float age = entity.tickCount + partialTick;
        float pulse = 1f + 0.05f * Mth.sin(age * 0.8f);
        float seed = entity.getId() * 1.37f;

        float cr = c.r(), cg = c.g(), cb = c.b();
        float hr = Mth.lerp(0.55f, cr, 1f), hg = Mth.lerp(0.55f, cg, 1f), hb = Mth.lerp(0.55f, cb, 1f);

        // --- 1) Nucleo solido: bloque de magma gigante girando, a brillo maximo ---
        pose.pushPose();
        pose.mulPose(Axis.XP.rotationDegrees(age * 2.3f));
        pose.mulPose(Axis.YP.rotationDegrees(age * 3.1f));
        pose.mulPose(Axis.ZP.rotationDegrees(age * 1.7f));
        float s = size * 0.9f;
        pose.scale(s, s, s);
        pose.translate(-0.5, -0.5, -0.5);
        this.blockRenderer.renderSingleBlock(Blocks.MAGMA_BLOCK.defaultBlockState(), pose, buffer,
                15728880, OverlayTexture.NO_OVERLAY);
        pose.popPose();

        // --- 2) Capas luminosas ---
        VertexConsumer vc = buffer.getBuffer(RenderType.lightning());

        pose.pushPose();
        Vec3 d = v.normalize();
        pose.mulPose(new Quaternionf().rotationTo(0f, 1f, 0f, (float) -d.x, (float) -d.y, (float) -d.z));

        GlowShapes.sphere(vc, pose, size * 0.55f * pulse, 10, 14, 0.10f, seed, 1f, 1f, 1f, 0.95f);
        GlowShapes.sphere(vc, pose, size * 0.80f * pulse, 10, 14, 0.18f, seed + 3f, hr, hg, hb, 0.75f);
        GlowShapes.sphere(vc, pose, size * 1.20f * pulse, 10, 14, 0.08f, seed + 7f, cr, cg, cb, 0.35f);
        GlowShapes.sphere(vc, pose, size * 1.90f * pulse, 8, 12, 0.04f, seed + 9f, cr, cg, cb, 0.12f);

        GlowShapes.tail(vc, pose, size * 12f, size * 0.5f, 12, 10, 1f, 1f, 1f, 0.85f);
        GlowShapes.tail(vc, pose, size * 20f, size * 0.9f, 14, 12, hr, hg, hb, 0.50f);
        GlowShapes.tail(vc, pose, size * 32f, size * 1.5f, 16, 14, cr, cg, cb, 0.22f);

        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(age * 3f));
        for (int i = 0; i < 6; i++) {
            pose.pushPose();
            pose.mulPose(Axis.YP.rotationDegrees(i * 60f));
            pose.mulPose(Axis.ZP.rotationDegrees(82f - (i % 2) * 18f));
            GlowShapes.spike(vc, pose, size * (2.6f + (i % 2) * 0.8f) * pulse, size * 0.16f, hr, hg, hb, 0.55f);
            pose.popPose();
        }
        pose.popPose();

        pose.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(MeteorEntity entity) {
        return new ResourceLocation("textures/misc/white.png");
    }
}
