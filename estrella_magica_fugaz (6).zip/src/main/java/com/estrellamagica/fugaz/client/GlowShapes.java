package com.estrellamagica.fugaz.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import org.joml.Matrix4f;

/** Geometria luminosa (esferas irregulares, conos y espinas) para dibujar el meteorito. */
public class GlowShapes {

    private static void vert(VertexConsumer vc, Matrix4f m, float r, float g, float b, float[] p) {
        vc.vertex(m, p[0], p[1], p[2]).color(r, g, b, p[3]).endVertex();
    }

    /** Cuadrilatero visible por las dos caras. p = {x, y, z, alpha}. */
    private static void quad(VertexConsumer vc, Matrix4f m, float r, float g, float b,
                             float[] p0, float[] p1, float[] p2, float[] p3) {
        vert(vc, m, r, g, b, p0);
        vert(vc, m, r, g, b, p1);
        vert(vc, m, r, g, b, p2);
        vert(vc, m, r, g, b, p3);
        vert(vc, m, r, g, b, p3);
        vert(vc, m, r, g, b, p2);
        vert(vc, m, r, g, b, p1);
        vert(vc, m, r, g, b, p0);
    }

    private static float[] spherePoint(float radius, float lat, float lon, float lump, float seed, float a) {
        float k = 1f + lump * (float) (Math.sin(lat * 3 + seed) * Math.cos(lon * 2 + seed * 1.7)
                + 0.5 * Math.sin(lon * 5 + seed * 0.6));
        float rr = radius * k;
        return new float[]{
                rr * (float) (Math.cos(lat) * Math.cos(lon)),
                rr * (float) Math.sin(lat),
                rr * (float) (Math.cos(lat) * Math.sin(lon)),
                a};
    }

    /** Esfera "rocosa" (con bultos si lump > 0). */
    public static void sphere(VertexConsumer vc, PoseStack pose, float radius, int rings, int segs,
                              float lump, float seed, float r, float g, float b, float a) {
        Matrix4f m = pose.last().pose();
        for (int i = 0; i < rings; i++) {
            float lat0 = (float) (Math.PI * (-0.5 + (double) i / rings));
            float lat1 = (float) (Math.PI * (-0.5 + (double) (i + 1) / rings));
            for (int j = 0; j < segs; j++) {
                float lon0 = (float) (Math.PI * 2 * j / segs);
                float lon1 = (float) (Math.PI * 2 * (j + 1) / segs);
                quad(vc, m, r, g, b,
                        spherePoint(radius, lat0, lon0, lump, seed, a),
                        spherePoint(radius, lat0, lon1, lump, seed, a),
                        spherePoint(radius, lat1, lon1, lump, seed, a),
                        spherePoint(radius, lat1, lon0, lump, seed, a));
            }
        }
    }

    /** Cola: cono que sale hacia +Y, se estrecha y se desvanece. */
    public static void tail(VertexConsumer vc, PoseStack pose, float length, float baseRadius,
                            int segs, int rings, float r, float g, float b, float alpha) {
        Matrix4f m = pose.last().pose();
        for (int i = 0; i < rings; i++) {
            float t0 = (float) i / rings;
            float t1 = (float) (i + 1) / rings;
            float y0 = length * t0, y1 = length * t1;
            float r0 = baseRadius * (float) Math.pow(1 - t0, 0.75);
            float r1 = baseRadius * (float) Math.pow(1 - t1, 0.75);
            float a0 = alpha * (float) Math.pow(1 - t0, 1.6);
            float a1 = alpha * (float) Math.pow(1 - t1, 1.6);
            for (int j = 0; j < segs; j++) {
                float ang0 = (float) (Math.PI * 2 * j / segs);
                float ang1 = (float) (Math.PI * 2 * (j + 1) / segs);
                quad(vc, m, r, g, b,
                        new float[]{r0 * (float) Math.cos(ang0), y0, r0 * (float) Math.sin(ang0), a0},
                        new float[]{r0 * (float) Math.cos(ang1), y0, r0 * (float) Math.sin(ang1), a0},
                        new float[]{r1 * (float) Math.cos(ang1), y1, r1 * (float) Math.sin(ang1), a1},
                        new float[]{r1 * (float) Math.cos(ang0), y1, r1 * (float) Math.sin(ang0), a1});
            }
        }
    }

    /** Espina luminosa (octaedro alargado) a lo largo de +Y, con la punta transparente. */
    public static void spike(VertexConsumer vc, PoseStack pose, float len, float w,
                             float r, float g, float b, float a) {
        Matrix4f m = pose.last().pose();
        float[] top = {0, len, 0, 0f};
        float[] bottom = {0, -len * 0.25f, 0, 0f};
        float[][] e = {
                {w, 0, 0, a}, {0, 0, w, a}, {-w, 0, 0, a}, {0, 0, -w, a}
        };
        for (int k = 0; k < 4; k++) {
            float[] e0 = e[k];
            float[] e1 = e[(k + 1) % 4];
            quad(vc, m, r, g, b, top, e0, e1, e1);
            quad(vc, m, r, g, b, bottom, e1, e0, e0);
        }
    }
}
