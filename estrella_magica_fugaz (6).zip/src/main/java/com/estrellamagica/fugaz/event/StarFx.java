package com.estrellamagica.fugaz.event;

import com.estrellamagica.fugaz.StarColor;
import com.estrellamagica.fugaz.particle.ModParticles;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

/** Efectos de particulas visibles desde muy lejos (hasta 250 bloques). */
public class StarFx {
    private static final double RANGE_SQR = 250.0 * 250.0;

    /** Explosion de chispas brillantes del color de la estrella. */
    public static void burst(ServerLevel level, Vec3 pos, StarColor color, int count, double spread) {
        for (ServerPlayer p : level.players()) {
            if (p.position().distanceToSqr(pos) > RANGE_SQR) continue;
            for (int i = 0; i < count; i++) {
                double dx = (level.random.nextDouble() - 0.5) * spread;
                double dy = (level.random.nextDouble() - 0.3) * spread;
                double dz = (level.random.nextDouble() - 0.5) * spread;
                // con count=0 el cliente recibe (r,g,b) como "velocidad": lo usamos como color
                level.sendParticles(p, ModParticles.STAR_GLOW.get(), true,
                        pos.x + dx, pos.y + dy, pos.z + dz, 0,
                        color.r(), color.g(), color.b(), 1.0);
            }
        }
    }

    /** Particulas vanilla con dispersion aleatoria. */
    public static void particles(ServerLevel level, Vec3 pos, ParticleOptions type, int count,
                                 double dx, double dy, double dz, double speed) {
        for (ServerPlayer p : level.players()) {
            if (p.position().distanceToSqr(pos) > RANGE_SQR) continue;
            level.sendParticles(p, type, true, pos.x, pos.y, pos.z, count, dx, dy, dz, speed);
        }
    }

    /** Anillo de particulas que se expande hacia fuera (onda de choque). */
    public static void ring(ServerLevel level, Vec3 pos, ParticleOptions type, int points, double speed, double yVel) {
        for (ServerPlayer p : level.players()) {
            if (p.position().distanceToSqr(pos) > RANGE_SQR) continue;
            for (int i = 0; i < points; i++) {
                double a = Math.PI * 2 * i / points;
                level.sendParticles(p, type, true, pos.x, pos.y, pos.z, 0,
                        Math.cos(a), yVel, Math.sin(a), speed);
            }
        }
    }
}
