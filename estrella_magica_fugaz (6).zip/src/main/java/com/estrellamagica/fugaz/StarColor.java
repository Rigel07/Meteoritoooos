package com.estrellamagica.fugaz;

import com.estrellamagica.fugaz.item.ModItems;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

public enum StarColor {
    //          color      id        reliquia                 prob. reliquia   bloque que tine el crater
    BLUE  (0x3DA5FF, "blue",   "celestial_heart",       0.30f, Blocks.BLUE_TERRACOTTA),
    PINK  (0xFF5FC8, "pink",   "stellar_petal",         0.20f, Blocks.PINK_TERRACOTTA),
    GREEN (0x4CFF7A, "green",  "cosmic_emerald_shard",  0.15f, Blocks.GREEN_TERRACOTTA),
    YELLOW(0xFFE347, "yellow", "solar_spark",           0.08f, Blocks.YELLOW_TERRACOTTA);

    public final int rgb;
    public final String id;
    public final String relicId;
    /** Probabilidad de que el meteorito suelte su objeto unico especial. */
    public final float relicChance;
    public final Block accentBlock;

    StarColor(int rgb, String id, String relicId, float relicChance, Block accentBlock) {
        this.rgb = rgb;
        this.id = id;
        this.relicId = relicId;
        this.relicChance = relicChance;
        this.accentBlock = accentBlock;
    }

    public float r() { return ((rgb >> 16) & 255) / 255f; }
    public float g() { return ((rgb >> 8) & 255) / 255f; }
    public float b() { return (rgb & 255) / 255f; }

    public Item fragment() { return ModItems.FRAGMENTS.get(this).get(); }
    public Item relic() { return ModItems.RELICS.get(this).get(); }

    public static StarColor byIndex(int i) {
        StarColor[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
