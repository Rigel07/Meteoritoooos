package com.estrellamagica.fugaz.entity;

import com.estrellamagica.fugaz.EstrellaMagicaFugaz;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, EstrellaMagicaFugaz.MOD_ID);

    public static final RegistryObject<EntityType<MeteorEntity>> METEOR =
            ENTITIES.register("meteor", () ->
                    EntityType.Builder.<MeteorEntity>of(MeteorEntity::new, MobCategory.MISC)
                            .sized(1.5f, 1.5f)
                            .fireImmune()
                            .noSave()
                            .clientTrackingRange(32)
                            .updateInterval(2)
                            .setShouldReceiveVelocityUpdates(true)
                            .build(new ResourceLocation(EstrellaMagicaFugaz.MOD_ID, "meteor").toString()));
}
